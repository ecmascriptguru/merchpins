chrome.runtime.sendMessage({main_action: 'show_window'});
window.close();